using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monstre : MonoBehaviour
{
    [SerializeField] AudioClip _sonManger;
    public void Manger()
    {
        SoundManager.Instance.JouerSon(_sonManger, 1f);
        GameManager.Instance.DesactiverNiveau();
    }
}
