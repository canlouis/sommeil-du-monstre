using System.Collections;
using UnityEngine;

public class Bloc : MonoBehaviour
{
    [SerializeField] float _vitesse = 5f;
    [SerializeField] float _vitesseChute = 2f; // Vitesse de chute lorsqu'il tombe
    [SerializeField] Transform[] _rayCastPoints; // Point de départ du raycast
    [SerializeField] AudioClip _sonBouger;
    [SerializeField] AudioClip _sonBumper;
    Rigidbody _rb;
    bool _estTombe = false; // Vérifie si le bloc est déjà tombé


    void Start()
    {
        _rb = GetComponent<Rigidbody>();
        _rb.interpolation = RigidbodyInterpolation.Interpolate;
        _rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
    }

    public bool PeutBouger(Vector3 direction)
    {
        if (_estTombe) return false; // Si le bloc est tombé, il ne peut plus bouger

        if (_rayCastPoints.Length == 0)
        {
            if (Physics.Raycast(transform.position, direction, out RaycastHit hit, 1f))
            {
                if (hit.collider.CompareTag("Obstacle") || hit.collider.CompareTag("Bloc") && hit.collider.gameObject != gameObject)
                {
                    SoundManager.Instance.JouerSon(_sonBumper, 0.6f);
                    return false; // Il y a un mur ou une autre boîte
                }
            }
        }
        else
        {
            foreach (Transform point in _rayCastPoints)
            {
                if (Physics.Raycast(point.position, direction, out RaycastHit hit, 1f))
                {
                    if (hit.collider.CompareTag("Obstacle") || hit.collider.CompareTag("Bloc") && hit.collider.gameObject != gameObject)
                    {
                        return false; // Il y a un mur ou une autre boîte
                    }
                }
            }
        }
        return true;
    }

    public void EssayerDeBouger(Vector3 direction)
    {
        if (_estTombe) return; // Ne pas bouger si le bloc est tombé

        Vector3 destination = transform.position + direction;
        if (PeutBouger(direction))
        {
            StartCoroutine(BougerVers(destination));
        }
    }

    IEnumerator BougerVers(Vector3 destination)
    {
        SoundManager.Instance.JouerSon(_sonBouger, 0.6f);
        while (Vector3.Distance(transform.position, destination) > 0.01f)
        {
            _rb.MovePosition(Vector3.MoveTowards(transform.position, destination, _vitesse * Time.fixedDeltaTime));
            yield return new WaitForFixedUpdate();
        }
        _rb.MovePosition(destination);

        // Vérifier si le bloc est sur un trou après s'être déplacé
        yield return new WaitForSeconds(0.1f); // Petite pause pour éviter un bug visuel

        if (EstAuDessusDunTrou())
        {
            StartCoroutine(ChuterDansTrou());
        }
    }

    bool EstAuDessusDunTrou()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.down, out hit, 1f))
        {
            return hit.collider.CompareTag("Trou");
        }
        return false;
    }

    IEnumerator ChuterDansTrou()
    {
        _estTombe = true;
        Vector3 destination = transform.position + Vector3.down * 5f; // Faire descendre le cube sous la grille

        while (Vector3.Distance(transform.position, destination) > 0.01f)
        {
            _rb.MovePosition(Vector3.MoveTowards(transform.position, destination, _vitesseChute * Time.fixedDeltaTime));
            yield return new WaitForFixedUpdate();
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Mort"))
        {
            StopAllCoroutines();
            GameManager.Instance.GestionObjetTombe(gameObject);
            _estTombe = false;
        }
    }
}
