using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OeilSpawn : MonoBehaviour
{
    [SerializeField] Vector2 _tailleNiveau = new Vector2(10, 10);
    [SerializeField] Vector2 _zoneSpawn = new Vector2(15, 15);

    [SerializeField] GameObject[] _oeilPrefabs;
    [SerializeField] int _nbOeils = 20;
    List<GameObject> _oeils = new List<GameObject>();
    int _indexActuelle = 0;

    void Start()
    {
        SpawnOeil();
    }

    void SpawnOeil()
    {
        for( int i = 0 ; i < _nbOeils ; i++ )
        {
            Vector3 position = new Vector3(Random.Range((float)-_zoneSpawn.x, _zoneSpawn.x), 0, Random.Range((float)-_zoneSpawn.y, _zoneSpawn.y));
            // if(position.x > -_tailleNiveau.x || position.x < _tailleNiveau.x || position.z > -_tailleNiveau.y || position.z < _tailleNiveau.y )
            // {
            //     i--;
            //     continue;
            // }
            // Vector3 position = new Vector3(Random.Range(-_tailleNiveau.x, _tailleNiveau.x), 0, Random.Range(-_tailleNiveau.y, _tailleNiveau.y));
            GameObject oeil = Instantiate(_oeilPrefabs[0], position, Quaternion.Euler(0, Random.Range(0,360), 0));
            float scale = Random.Range(0.6f,1.4f);
            oeil.transform.localScale = new Vector3(scale,scale,scale);
            oeil.transform.parent = transform;
            _oeils.Add(oeil);
            
        }
        foreach(GameObject oeil in _oeils)
        {
            StartCoroutine(CoroutineWobbleOeil(oeil));
        }
    }

    public void Destroy()
    {
        StopAllCoroutines();
        foreach(GameObject oeil in _oeils)
        {
            Destroy(oeil);
        }

    }

    public void ChangerOeil(int index)
    {
        if(_indexActuelle == index) return;
        List<GameObject> newList = new List<GameObject>();

        foreach(GameObject oeil in _oeils)
        {
            GameObject newOeil = Instantiate(_oeilPrefabs[index], oeil.transform.position, oeil.transform.rotation, transform);
            // _oeils.Add(newOeil);
            newList.Add(newOeil);
            // oeil.SetActive(false);
            // _oeils.Remove(oeil);
            // Destroy(oeil);
        }
        StopAllCoroutines();
        // _oeils[_indexActuelle].SetActive(false);
        foreach(GameObject oeil in _oeils)
        {
            if(oeil != null) Destroy(oeil);
        }
        _oeils = newList;
        _indexActuelle = index;
        
        foreach(GameObject oeil in _oeils)
        {
            StartCoroutine(CoroutineWobbleOeil(oeil));
        }
        // _oeils[_indexActuelle].SetActive(true);
    }

    IEnumerator CoroutineWobbleOeil(GameObject oeil)
    {

        float posXInit = oeil.transform.position.x;
        float posZInit = oeil.transform.position.z;
        while(true)
        {
            Vector3 position = oeil.transform.position;
            position.y = 0.5f + Mathf.Sin(Time.time * 2) * 0.1f;
            position.x = posXInit + Mathf.Cos(Time.time * 2) * 0.1f;
            position.z = posZInit + Mathf.Sin(Time.time * 2) * 0.1f;
            oeil.transform.position = position;
            yield return null;
        }
    }
}
