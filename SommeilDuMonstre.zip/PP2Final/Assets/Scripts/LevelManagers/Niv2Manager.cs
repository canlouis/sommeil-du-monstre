using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Cinemachine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.InputSystem;
using Unity.VisualScripting;

public class Niv2Manager : MonoBehaviour
{
    [SerializeField] AudioClip _sonGrognement;
    [SerializeField] float _ecartGrognement = 2f;
    [SerializeField] GameObject[] _flammes;
    [SerializeField] SoundManager _soundManager;
    [SerializeField] AudioClip _sonFeuApparition;
    [SerializeField] AudioClip _sonFeu;

    void Start()
    {
        StartCoroutine(Grognement());
        GameManager.mortEvent.AddListener(Arreter);
    }

    IEnumerator Grognement()
    {
        float dureeGrognement = 5f;
        while (true)
        {
            _soundManager.JouerSon(_sonFeuApparition, 1f);
            StartCoroutine(_soundManager.JouerSonFadeOut(_sonFeu, dureeGrognement, 2f));
            foreach (GameObject flamme in _flammes)
            {
                flamme.GetComponent<Collider>().enabled = true;
                foreach (Transform enfant in flamme.transform)
                {
                    enfant.GetComponent<ParticleSystem>().Play();
                }
            }

            StartCoroutine(_soundManager.JouerSonFadeOut(_sonGrognement, dureeGrognement));
            yield return new WaitForSeconds(dureeGrognement);

            foreach (GameObject flamme in _flammes)
            {
                flamme.GetComponent<Collider>().enabled = false;
                foreach (Transform enfant in flamme.transform)
                {
                    enfant.GetComponent<ParticleSystem>().Stop();
                }
            }

            yield return new WaitForSeconds(_ecartGrognement);
        }
    }

    void Arreter()
    {
        StopAllCoroutines();
        foreach (GameObject flamme in _flammes)
        {
            flamme.GetComponent<Collider>().enabled = false;
            foreach (Transform enfant in flamme.transform)
            {
                enfant.GetComponent<ParticleSystem>().Stop();
            }
        }
    }
}
