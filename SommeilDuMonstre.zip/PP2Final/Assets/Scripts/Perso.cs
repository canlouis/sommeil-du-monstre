using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;
using Cinemachine;

public class Perso : MonoBehaviour
{
    [SerializeField] float _vitesse = 5f;
    [SerializeField] CinemachineVirtualCamera _cam;
    [SerializeField] ParticleSystem _particulesTomber;
    [SerializeField] AudioClip _sonBouger;
    [SerializeField] AudioClip _sonTomber;
    [SerializeField] AudioClip _sonBumper;
    [SerializeField] AudioClip _sonMort;
    [SerializeField] SONavigation _navigation;
    Vector3 _posInitiale;
    RigidbodyConstraints _constraint;
    [SerializeField] Animator _animator = null;
    [SerializeField] Transform _playerTransform;
    Rigidbody _rb;
    PlayerInput _playerInput;
    InputAction _accelererTemps;
    bool _enDeplacement = false;
    bool _estTombe = false; // Vérifie si le personnage est tombé
    Vector2 _direction;
    public CinemachineVirtualCamera Cam { set => _cam = value; }
    public bool EstTombe { get => _estTombe; set => _estTombe = value; }

    void Start()
    {
        _rb = GetComponent<Rigidbody>();
        _playerInput = GetComponent<PlayerInput>();
        _accelererTemps = _playerInput.actions["AccelererTemps"];
        _accelererTemps.performed += _ => GameManager.Instance.VitesseAcceleration = GameManager.Instance.VitesseAccelerationInit;
        _accelererTemps.canceled += _ => GameManager.Instance.VitesseAcceleration = 1;
        _rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        _posInitiale = transform.position;
        Tomber();
    }

    void OnMove(InputValue value)
    {
        if (_enDeplacement || _estTombe) return;

        Vector2 input = value.Get<Vector2>();
        if (input == Vector2.zero) return;

        // 🔹 Rendre le mouvement strictement horizontal ou vertical
        if (Mathf.Abs(input.x) > Mathf.Abs(input.y))
        {
            _direction = new Vector2(Mathf.RoundToInt(input.x), 0); // Garde seulement l'axe X
        }
        else
        {
            _direction = new Vector2(0, Mathf.RoundToInt(input.y)); // Garde seulement l'axe Y
        }

        Vector3 direction = new Vector3(_direction.x, 0, _direction.y);
        Vector3 destination = transform.position + direction;

        if (DestinationIsValide(direction))
        {
            if(_animator.GetBool("isPushing") == false)
            {
                _animator.SetBool("isWalking", true);
                
            }
            else
            {
                _animator.SetBool("isWalking", false);
            }
            StartCoroutine(CoroutineBougerVers(destination));
        }
    }

    bool DestinationIsValide(Vector3 direction)
    {
        GameManager.moveEvent.Invoke();
        if (_rb.SweepTest(direction, out RaycastHit hit, .2f)) // Vérifie la collision avant de bouger
        {
            if (hit.collider.CompareTag("Bloc"))
            {
                Bloc bloc = hit.collider.GetComponent<Bloc>();
                if (bloc.PeutBouger(direction))
                {
                    bloc.EssayerDeBouger(direction);
                    return true; // Bouger après la boîte
                }
                else
                {
                    Debug.Log("Boîte bloquée !");
                    return false;
                }
            }
            else if (hit.collider.CompareTag("Obstacle"))
            {
                SoundManager.Instance.JouerSon(_sonBumper, 0.6f);
                Debug.Log("Obstacle détecté !");
                return false;
            }
        }
        return true; // Aucune collision, déplacement valide
    }

    IEnumerator CoroutineBougerVers(Vector3 destination)
    {
        SoundManager.Instance.JouerSon(_sonBouger, 0.6f);
        _enDeplacement = true;
        int targetAngle = (int)(Mathf.Atan2(_direction.x, _direction.y) * Mathf.Rad2Deg);

        while (Vector3.Distance(transform.position, destination) > 0.1f)
        {
            transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(0, targetAngle, 0), 180 * Time.deltaTime * _vitesse);
            transform.position = Vector3.MoveTowards(transform.position, destination, _vitesse * Time.deltaTime);

            yield return null;
        }
        _direction = Vector2.zero;
        _animator.SetBool("isWalking", false);
        _playerTransform.localPosition = Vector3.zero;
        _playerTransform.localRotation = Quaternion.identity;
        transform.rotation = Quaternion.Euler(0, targetAngle, 0);
        transform.position = new Vector3(Mathf.Round(transform.position.x), transform.position.y, Mathf.Round(transform.position.z));
        _enDeplacement = false;

        if (EstAuDessusDunTrou())
        {
            ChuterDansTrou();
        }
    }

    IEnumerator CoroutineShakeCamera()
    {
        if (_cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>() == null) yield break;
        _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_AmplitudeGain = 1f;
        _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_FrequencyGain = 10;
        yield return new WaitForSeconds(0.2f);
        _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_AmplitudeGain = 0;
        _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_FrequencyGain = 0;
    }

    void Tomber()
    {
        transform.position = new Vector3(transform.position.x, transform.position.y + 20, transform.position.z);
        _rb.isKinematic = false;
        _rb.useGravity = true;
        _enDeplacement = true;
        // _cam.Follow = null;
        _rb.constraints = RigidbodyConstraints.None;
        StartCoroutine(CoroutineCheckSol());
    }

    IEnumerator CoroutineCheckSol()
    {
        yield return new WaitForSeconds(0.1f);
        SoundManager.Instance.JouerSon(_sonTomber, 0.6f);
        while (transform.position.y > _posInitiale.y)
        {
            yield return null;
        }
        StartCoroutine(CoroutineShakeCamera());
        Instantiate(_particulesTomber, transform.position, Quaternion.Euler(-90, 0, 0));
        _cam.Follow = transform;
        _rb.isKinematic = true;
        _rb.useGravity = false;
        transform.position = _posInitiale;
        _enDeplacement = false;
        _rb.constraints = RigidbodyConstraints.FreezePositionY | RigidbodyConstraints.FreezeRotation;
        StartCoroutine(GameManager.Instance.CoroutineFinNuit());
        StartCoroutine(GameManager.Instance.CoroutineSommeil());
    }

    bool EstAuDessusDunTrou()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.down, out hit, 1f))
        {
            return hit.collider.CompareTag("Trou");
        }
        return false;
    }

    void ChuterDansTrou()
    {
        _estTombe = true;
        _constraint = _rb.constraints; // Sauvegarder les contraintes actuelles
        _rb.constraints = RigidbodyConstraints.None; // Désactiver les contraintes pour une chute naturelle
        _rb.useGravity = true; // Activer la gravité pour une chute naturelle
        _rb.isKinematic = false; // Désactiver le mode kinematic
        _cam.Follow = null; // Désactiver le suivi de la caméra
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Mort"))
        {
            _rb.useGravity = false; // Activer la gravité pour une chute naturelle
            _rb.isKinematic = true; // Désactiver le mode kinematic
            _rb.constraints = _constraint; // Rétablir les contraintes
            GameManager.Instance.GestionObjetTombe(gameObject);
        }
        else if(other.CompareTag("Feu"))
        {
            Mourir();
        }
    }

    public void DesactiverMouvement()
    {
        _playerInput.enabled = false;
    }

    public void OnRecommencer(){
        SoundManager.Instance.ArreterSon();
        _navigation.Rejouer();
    }

    public IEnumerator CoroutineMourirMonstre()
    {
        GameManager.mortEvent.Invoke();
        SoundManager.Instance.JouerSon(_sonMort, 0.4f);
        gameObject.SetActive(false);

        float t = 0;
        while (t < 1)
        {
            t += Time.deltaTime;
            _cam.m_Lens.OrthographicSize = Mathf.Lerp(5, 13, t);
            yield return null;
        }
        // _donneesNavigation.AllerSceneFin();
        GameManager.Instance.ActiverMonstre();
    }

    public void Mourir()
    {
        GameManager.mortEvent.Invoke();
        SoundManager.Instance.JouerSon(_sonMort, 0.4f);
        _enDeplacement = true;
        gameObject.SetActive(false);
        OnRecommencer();
    }
}
