using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grille : MonoBehaviour
{
    [SerializeField] private GameObject _dallePrefab;
    [SerializeField] Vector2 _tailleGrille;
    Grid _grid;
    List<GameObject> _dalles = new List<GameObject>();
    // Start is called before the first frame update
    void Start()
    {
        _grid = GetComponent<Grid>();
        CreerGrille();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void CreerGrille()
    {
        for (int x = 0; x < _tailleGrille.x; x++)
        {
            for (int z = 0; z < _tailleGrille.y; z++)
            {
                Vector3 posDalle = _grid.GetCellCenterWorld(new Vector3Int(x, 0, z));
                GameObject dalle = Instantiate(_dallePrefab, posDalle, Quaternion.identity);
                dalle.transform.SetParent(transform);
                _dalles.Add(dalle);
            }
        }
    }

    public Vector3 GetPositionDalle(Vector3 position)
    {
        Vector3Int cellPosition = _grid.WorldToCell(position);
        return _grid.GetCellCenterWorld(cellPosition);
    }
}