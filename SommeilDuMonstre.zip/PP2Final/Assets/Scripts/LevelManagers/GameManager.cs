using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Cinemachine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [SerializeField] Perso _joueur;
    [SerializeField] GameObject[] _objetsUiReve;
    [SerializeField] GameObject[] _reveBlocs;
    [SerializeField] GameObject[] _realBlocs;
    [SerializeField] Image _barreSommeil;
    [SerializeField] GameObject _aiguilleHorloge;
    [SerializeField] TextMeshProUGUI _tempsRestantNuit;
    [SerializeField] private CinemachineVirtualCamera _cam;
    [SerializeField] float _tempsAvantFinNuitInit = 60f;
    [SerializeField] float _sommeilInit = 20f;
    [SerializeField] float _qteSommeilAjout = 5f;
    [SerializeField] Volume _volume;
    [SerializeField] VolumeProfile _profile;
    [SerializeField] VolumeProfile _intermediateProfile;
    [SerializeField] float _fadeDuration = 0.2f;
    [SerializeField] Material _disolveMaterial;
    [SerializeField] GameObject[] _yeux;
    [SerializeField] Canvas _UiCanvas;
    [SerializeField] Transform[] _posReapparitionBloc;
    [SerializeField] float _vitesseAccelerationTempsInit = 1f;
    [SerializeField] AudioClip _sonReveIn;
    [SerializeField] AudioClip _sonReveOut;
    [SerializeField] AudioClip _sonGrowl;
    [SerializeField] GameObject _monstre;
    [SerializeField] GameObject _niveau;
    [SerializeField] SONavigation _donneesNavigation;
    [SerializeField] Transform _posCamMonstre;
    [SerializeField] OeilSpawn _oeilSpawn;
    [SerializeField] GameObject _finNiveauPanel;
    
    List<GameObject> _blocsReveListe = new();
    List<GameObject> _blocsRealListe = new();
    List<float> _posYObjetsUiReve = new();
    List<float> _tailleObjetsUiReve = new();
    bool _aUnObjetReve = false;
    bool _aDeuxiemeObjetReve = false;
    GameObject _objetReve;
    int _indexYeuxActifs = 0;
    int _indexObjetUiReve = 0;
    int _indexDernierYeuxActif = 0;
    float _tempsAvantFinNuit;
    float _sommeil;
    float _vitesseAcceleration = 1f;
    VolumeProfile _initialProfile;
    bool _enReve = false;
    public bool EnReve { get => _enReve; set => _enReve = value; }
    public float TempsAvantFinNuit { get => _tempsAvantFinNuit; set => _tempsAvantFinNuit = value; }
    public float Sommeil { get => _sommeil; set => _sommeil = value; }
    public float VitesseAcceleration { get => _vitesseAcceleration; set => _vitesseAcceleration = value; }
    public float VitesseAccelerationInit { get => _vitesseAccelerationTempsInit; set => _vitesseAccelerationTempsInit = value; }
    public static GameManager Instance { get; private set; }
    private static UnityEvent _moveEvent;
    private static UnityEvent _mortEvent;
    public static UnityEvent moveEvent
    {
        get
        {
            if (_moveEvent == null)
            {
                _moveEvent = new UnityEvent();
            }
            return _moveEvent;
        }
    }
    public static UnityEvent mortEvent
    {
        get
        {
            if (_mortEvent == null)
            {
                _mortEvent = new UnityEvent();
            }
            return _mortEvent;
        }
    }

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
        _joueur.Cam = _cam;
    }

    void Start()
    {
        _tempsAvantFinNuit = _tempsAvantFinNuitInit;
        _sommeil = _sommeilInit;
        _initialProfile = _volume.profile;

        foreach (GameObject bloc in _reveBlocs)
        {
            _blocsReveListe.Add(bloc);


        }

        foreach (GameObject bloc in _realBlocs)
        {
            _blocsRealListe.Add(bloc);
        }

        _monstre.SetActive(false);

        for (int i = 0; i < _objetsUiReve.Length; i++)
        {
            _posYObjetsUiReve.Add(_objetsUiReve[i].transform.position.y);
            _tailleObjetsUiReve.Add(_objetsUiReve[i].transform.localScale.y);
            _objetsUiReve[i].transform.localScale = Vector3.zero;
        }
    }

    public IEnumerator CoroutineFinNuit()
    {
        while (_tempsAvantFinNuit > 0)
        {
            if (_enReve) yield break;
            _tempsAvantFinNuit -= _vitesseAcceleration * Time.deltaTime;
            _aiguilleHorloge.transform.localRotation = Quaternion.Euler(0, _tempsAvantFinNuit / _tempsAvantFinNuitInit * -360, 0);
            _tempsRestantNuit.text = Mathf.RoundToInt(_tempsAvantFinNuit).ToString();
            yield return null;
        }
        _tempsRestantNuit.text = "0";

        // Fin Niveau
        _finNiveauPanel.SetActive(true);
        _joueur.GetComponent<PlayerInput>().enabled = false;


        int indexNiveau = SceneManager.GetActiveScene().buildIndex - 1;

        if(PlayerPrefs.GetInt("NiveauAtteint") < indexNiveau)
        {
            PlayerPrefs.SetInt("NiveauAtteint", indexNiveau);
        }
        StopAllCoroutines();
    }

    public IEnumerator CoroutineSommeil()
    {
        while (_sommeil > 0)
        {
            if (_enReve) yield break;
            _sommeil -= _vitesseAcceleration * Time.deltaTime;
            _barreSommeil.fillAmount = _sommeil / _sommeilInit;

            if (_sommeil >= _sommeilInit * .75f)
            {
                _indexYeuxActifs = 0;
                _oeilSpawn.ChangerOeil(0);
            }
            else if (_sommeil >= _sommeilInit * .5f)
            {
                _indexYeuxActifs = 1;
                _oeilSpawn.ChangerOeil(1);
            }
            else if (_sommeil >= _sommeilInit * .25f)
            {
                _indexYeuxActifs = 2;
                _oeilSpawn.ChangerOeil(2);
            }
            else
            {
                _indexYeuxActifs = 3;
                _oeilSpawn.ChangerOeil(3);
            }

            if (_indexYeuxActifs != _indexDernierYeuxActif) _yeux[_indexDernierYeuxActif].SetActive(false);
            _yeux[_indexYeuxActifs].SetActive(true);
            _indexDernierYeuxActif = _indexYeuxActifs;
            yield return null;
        }

        ActiverMonstre();
    }

    public void GestionObjetTombe(GameObject objet)
    {
        if (objet.GetComponent<Perso>() != null) _indexObjetUiReve = 1;
        else _indexObjetUiReve = 0;


        if (_enReve)
        {
            if (_aUnObjetReve)
            {
                _aDeuxiemeObjetReve = true;
                StartCoroutine(FaireApparaitreObjetReve());
            }
            else
            {
                StartCoroutine(FaireApparaitreBlocUI(objet));
            }
        }
        else
        {
            if (_indexObjetUiReve == 0)
            {
                AjouterSommeil();
                Destroy(objet);
            }
            else
            {
                StartCoroutine(objet.GetComponent<Perso>().CoroutineMourirMonstre());
            }
        }
    }

    IEnumerator FaireApparaitreBlocUI(GameObject objet)
    {
        objet.SetActive(false);

        _aUnObjetReve = true;
        _objetReve = objet;

        _objetsUiReve[_indexObjetUiReve].SetActive(true);

        float posBlocY = _objetsUiReve[_indexObjetUiReve].transform.position.y;
        _objetsUiReve[_indexObjetUiReve].transform.localPosition = new Vector3(0, posBlocY, 0);

        float tempsEcoule = 0;
        float duree = 1f;

        while (tempsEcoule < duree)
        {
            tempsEcoule += Time.deltaTime;
            _objetsUiReve[_indexObjetUiReve].transform.localScale = Vector3.Lerp(Vector3.zero, Vector3.one * _tailleObjetsUiReve[_indexObjetUiReve], tempsEcoule / duree);
            yield return null;
        }


        if (_indexObjetUiReve == 1) ChangePostProcess();
    }

    IEnumerator FaireApparaitreObjetReve()
    {
        if (_objetReve == null) yield break;

        bool peutApparaitre = false;

        while (!peutApparaitre)
        {
            int posRandom = Random.Range(0, _posReapparitionBloc.Length);
            RaycastHit hit;
            if (Physics.Raycast(_posReapparitionBloc[posRandom].position, Vector3.down, out hit, 2f))
            {
                if (hit.collider.CompareTag("Untagged"))
                {
                    _objetReve.transform.position = _posReapparitionBloc[posRandom].position;
                    peutApparaitre = true;
                }
            }
        }

        yield return new WaitForSeconds(1f);

        yield return StartCoroutine(CoroutineTransitionBlocsFadeIn(_objetsUiReve[_indexObjetUiReve]));
        _objetReve.SetActive(true);
        StartCoroutine(CoroutineTransitionBlocsFadeIn(_objetReve, true));
        _objetsUiReve[_indexObjetUiReve].transform.localScale = Vector3.zero;
        Perso perso = _objetReve.GetComponent<Perso>();
        if (perso != null)
        {
            perso.Cam = _cam;
            _cam.Follow = perso.transform;
            perso.EstTombe = false;
        }
        else if (!_aDeuxiemeObjetReve)
        {
            _blocsReveListe.Remove(_objetReve);
            _blocsRealListe.Add(_objetReve);
            _aUnObjetReve = false;
        }
        else
        {
            _aDeuxiemeObjetReve = false;
            StartCoroutine(FaireApparaitreBlocUI(_objetReve));
        }

    }

    void AjouterSommeil()
    {
        _sommeil += _qteSommeilAjout;
        if (_sommeil > _sommeilInit) _sommeil = _sommeilInit;
    }

    public void ChangePostProcess()
    {
        if (!_enReve)
        {
            SoundManager.Instance.JouerSon(_sonReveIn, 0.5f);
            _volume.profile = _initialProfile;
            StartCoroutine(CoroutineFadeVolumeReve());
            _enReve = true;
        }
        else
        {
            SoundManager.Instance.JouerSon(_sonReveOut, 0.5f);
            _volume.profile = _profile;
            StartCoroutine(CoroutineFadeVolumeNormal());
            _enReve = false;
            StartCoroutine(CoroutineSommeil());
            StartCoroutine(CoroutineFinNuit());
            if (_aUnObjetReve) StartCoroutine(FaireApparaitreObjetReve());
        }
    }

    IEnumerator CoroutineFadeVolumeReve()
    {
        ActiverReve();
        // _intermediateProfile.TryGet(out Bloom bloom);
        _volume.profile = _intermediateProfile;

        Color finalColor = new Color(1, 0, 0.5f, 1);
        _volume.profile.TryGet(out LensDistortion ld);
        _volume.profile.TryGet(out Bloom bloom);
        _volume.profile.TryGet(out Vignette vignette);
        _volume.profile.TryGet(out ShadowsMidtonesHighlights smh);

        _profile.TryGet(out LensDistortion ldTarget);
        _profile.TryGet(out Bloom bloomTarget);
        _profile.TryGet(out Vignette vignetteTarget);
        _profile.TryGet(out ShadowsMidtonesHighlights smhTarget);
        float t = 0;
        while (t < _fadeDuration)
        {
            t += Time.deltaTime;
            Color currentColor = bloom.tint.value;
            ld.intensity.value = Mathf.Lerp(ld.intensity.value, ldTarget.intensity.value, t);
            bloom.tint.value = Color.Lerp(currentColor, bloomTarget.tint.value, t / _fadeDuration);
            vignette.intensity.value = Mathf.Lerp(vignette.intensity.value, vignetteTarget.intensity.value, t / _fadeDuration);
            smh.shadows.value = Vector4.Lerp(smh.shadows.value, smhTarget.shadows.value, t / _fadeDuration);
            yield return null;
        }
        ld.intensity.value = ldTarget.intensity.value;
        bloom.tint.value = bloomTarget.tint.value;
        _volume.profile = _profile;

    }

    void ActiverReve()
    {
        SoundManager.Instance.ActiverReverb(true);
        foreach (GameObject objet in _blocsReveListe)
        {
            if (objet != null)
            {
                objet.SetActive(true);
                if (objet.tag == "Trou")
                {
                    objet.tag = "Untagged";
                    foreach (Transform enfant in objet.transform)
                    {
                        foreach (Renderer renderer in enfant.GetComponentsInChildren<Renderer>())
                        {
                            renderer.enabled = true;
                        }
                        enfant.tag = "Untagged";
                    }
                }
                if (objet.GetComponent<Piques>() != null) objet.GetComponent<Piques>().ActivateCoroutines();
                if (objet.GetComponent<BoutonPorte>() != null) objet.GetComponent<BoutonPorte>().ActivateCoroutines();
                StartCoroutine(CoroutineTransitionBlocsFadeIn(objet, true));
            }
        }

        foreach (GameObject objet in _blocsRealListe)
        {
            if (objet != null)
            {
                StartCoroutine(CoroutineTransitionBlocsFadeIn(objet));
            }
        }
    }

    IEnumerator CoroutineFadeVolumeNormal()
    {
        DesactiverReve();
        _volume.profile = _intermediateProfile;
        Color finalColor = new Color(0, 0, 0, 1);
        _volume.profile.TryGet(out LensDistortion ld);
        _volume.profile.TryGet(out Bloom bloom);
        _volume.profile.TryGet(out Vignette vignette);
        _volume.profile.TryGet(out ShadowsMidtonesHighlights smh);

        _initialProfile.TryGet(out Bloom bloomTarget);
        // _initialProfile.TryGet(out Vignette vignetteTarget);
        float t = 0;
        while (t < _fadeDuration)
        {

            t += Time.deltaTime;
            Color initialColor = bloom.tint.value;
            // ld.intensity.value = Mathf.Lerp(0.3f, 0, t);

            ld.intensity.value = Mathf.Lerp(ld.intensity.value, 0.01f, t / _fadeDuration);
            bloom.tint.value = Color.Lerp(initialColor, bloomTarget.tint.value, t / _fadeDuration);
            vignette.intensity.value = Mathf.Lerp(vignette.intensity.value, 0, t / _fadeDuration);
            smh.shadows.value = Vector4.Lerp(smh.shadows.value, new Vector4(1, 1, 1, 0), t / _fadeDuration);
            yield return null;
        }
        // ld.intensity.value = 0;

        bloom.tint.value = bloomTarget.tint.value;
        _volume.profile = _initialProfile;

    }

    void DesactiverReve()
    {
        foreach (GameObject bloc in _blocsReveListe)
        {
            if (bloc != null)
            {
                if (bloc.tag == "Untagged")
                {
                    bloc.tag = "Trou";
                    foreach (Transform enfant in bloc.transform)
                    {
                        foreach (Renderer renderer in enfant.GetComponentsInChildren<Renderer>())
                        {
                            renderer.enabled = false;
                        }
                        enfant.tag = "Trou";
                    }
                }
                StartCoroutine(CoroutineTransitionBlocsFadeIn(bloc));
            }
        }

        foreach (GameObject bloc in _blocsRealListe)
        {
            if (bloc != null)
            {
                bloc.SetActive(true);
                if (bloc.GetComponent<Piques>() != null) bloc.GetComponent<Piques>().ActivateCoroutines();
                if (bloc.GetComponent<BoutonPorte>() != null) bloc.GetComponent<BoutonPorte>().ActivateCoroutines();

                StartCoroutine(CoroutineTransitionBlocsFadeIn(bloc, true));
            }
        }
    }

    IEnumerator CoroutineTransitionBlocsFadeIn(GameObject bloc, bool inverse = false)
    {
        if (bloc == null) yield break;
        Renderer[] renderers = bloc.GetComponentsInChildren<Renderer>();
        Dictionary<Renderer, Material[]> materials = new Dictionary<Renderer, Material[]>();
        Dictionary<Renderer, Material[]> iniMaterials = new Dictionary<Renderer, Material[]>();

        foreach (Renderer renderer in renderers)
        {
            if (renderer != null)
            {
                materials.Add(renderer, renderer.materials);
                iniMaterials.Add(renderer, renderer.materials);
            }
        }

        foreach (KeyValuePair<Renderer, Material[]> renderer in materials)
        {
            for (int i = 0; i < renderer.Value.Length; i++)
            {
                renderer.Value[i] = _disolveMaterial;
            }
            renderer.Key.materials = renderer.Value;
        }

        float t = 0;
        while (t < _fadeDuration)
        {

            t += Time.deltaTime;
            float ratio = inverse ? 1 - (t / _fadeDuration) : t / _fadeDuration;

            foreach (KeyValuePair<Renderer, Material[]> renderer in materials)
            {
                for (int i = 0; i < renderer.Value.Length; i++)
                {
                    MaterialPropertyBlock block = new MaterialPropertyBlock();
                    if (block != null)
                    {
                        block.SetColor("_matColor", iniMaterials[renderer.Key][i].color);
                        block.SetFloat("_roughness", iniMaterials[renderer.Key][i].GetFloat("_Smoothness"));
                        block.SetFloat("_metalness", iniMaterials[renderer.Key][i].GetFloat("_Metallic"));
                        block.SetFloat("_dissolve", ratio);

                        renderer.Key.SetPropertyBlock(block, i);
                    }
                }
                // renderer.Key.materials = renderer.Value;
            }
            yield return null;

        }

        foreach (KeyValuePair<Renderer, Material[]> renderer in materials)
        {
            renderer.Key.materials = iniMaterials[renderer.Key];
        }
        if (!inverse)
        {
            if (bloc.GetComponent<Piques>() != null) bloc.GetComponent<Piques>().DisableCoroutines();
            if (bloc.GetComponent<BoutonPorte>() != null) bloc.GetComponent<BoutonPorte>().DisableCoroutines();
            if (bloc.tag != "Trou") bloc.SetActive(false);
            else
            {
                foreach (Transform enfant in bloc.transform)
                {
                    foreach (Renderer renderer in enfant.GetComponentsInChildren<Renderer>())
                    {
                        renderer.enabled = false;
                    }
                }
            }
        }

    }

    public void ActiverMonstre()
    {
        StopAllCoroutines();
        StartCoroutine(CoroutineShakeCamera());
        SoundManager.Instance.JouerSon(_sonGrowl, 0.8f, false);
        if (_enReve) ChangePostProcess();
        _joueur.DesactiverMouvement();
        _oeilSpawn.Destroy();
        StartCoroutine(CoroutineZoomOut());
    }

    IEnumerator CoroutineZoomOut()
    {
        float duree = 3f;
        float t = 0;
        _cam.Follow = null;
        while (t < duree)
        {
            t += Time.deltaTime;
            _cam.transform.position = Vector3.Lerp(_cam.transform.position, _posCamMonstre.position, t / duree);
            RenderSettings.ambientIntensity = Mathf.Lerp(1, 0f, t / duree);
            RenderSettings.reflectionIntensity = Mathf.Lerp(1, 0f, t / duree);

            yield return null;
        }
        _monstre.SetActive(true);
        _UiCanvas.gameObject.SetActive(false);
    }

    public void DesactiverNiveau()
    {
        _niveau.SetActive(false);
        StartCoroutine(CoroutineAllerFin());
    }

    IEnumerator CoroutineShakeCamera()
    {
        float t = 0;
        float duree = 1f;
        while (t < duree)
        {
            t += Time.deltaTime;
            _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_AmplitudeGain = Mathf.Lerp(0, 1, t / duree);   
            _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_FrequencyGain = Mathf.Lerp(0, 1, t / duree);
            yield return null;
        }
        _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_AmplitudeGain = 0;
        _cam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>().m_FrequencyGain = 0;
    }

    IEnumerator CoroutineAllerFin()
    {
        yield return new WaitForSeconds(2);
        _donneesNavigation.Rejouer();

    }

    IEnumerator Instructions()
    {
        yield return new WaitForSeconds(2);
        _joueur.GetComponent<PlayerInput>().enabled = true;
    }
}
