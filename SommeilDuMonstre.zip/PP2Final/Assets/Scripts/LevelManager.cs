using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class LevelManager : MonoBehaviour
{
    [SerializeField] GameObject IntroPanel;
    [SerializeField] GameObject NiveauxPanel;
    [SerializeField] Button[] NiveauxBoutons;
    // Start is called before the first frame update
    void Start()
    {
        // PlayerPrefs.SetInt("NiveauAtteint", 0);
        // Debug.Log(PlayerPrefs.GetInt("NiveauAtteint", 0));
        if (PlayerPrefs.GetInt("NiveauAtteint", 0) > 1)
        {
            ActiverNiveaux();
            // IntroPanel.SetActive(false);
            // NiveauxPanel.SetActive(true);
        }
        else
        {

            ActiverIntro();
            // IntroPanel.SetActive(true);
            // NiveauxPanel.SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void ActiverNiveaux()
    {
        IntroPanel.SetActive(false);
        NiveauxPanel.SetActive(true);

        PlayerPrefs.GetInt("NiveauAtteint", 1);

        for (int i = 0; i < NiveauxBoutons.Length; i++)
        {
            if (i <= PlayerPrefs.GetInt("NiveauAtteint", 0))
            {
                NiveauxBoutons[i].interactable = true;
            }
            else
            {
                NiveauxBoutons[i].interactable = false;
            }
        }
    }

    public void ActiverIntro()
    {
        IntroPanel.SetActive(true);
        NiveauxPanel.SetActive(false);
    }

    
}
