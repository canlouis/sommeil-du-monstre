using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Piques : MonoBehaviour
{
    bool _estActif = false;
    [SerializeField] GameObject _piques;
    [SerializeField] AudioClip _sonPiques;
    [SerializeField] bool _estActifAuDebut = false;
    Collider _collider;
    // Start is called before the first frame update
    
    void Awake()
    {
        _collider = GetComponent<Collider>();
    }
    void Start()
    {
        GameManager.moveEvent.AddListener(AlternanceEtat);
        _estActif = _estActifAuDebut;
        // _collider = GetComponent<Collider>();
    }

    void AlternanceEtat()
    {
        _estActif = !_estActif;
        StopAllCoroutines();

        // _piques.transform.position = _estActif ? new Vector3(transform.position.x, transform.position.y + 0.7f, transform.position.z) : new Vector3(transform.position.x, transform.position.y - 0.5f, transform.position.z); 
        
        // Debug.Log("AlternanceEtat");
        StartCoroutine(ActiverPiques());
    }

    IEnumerator ActiverPiques()
    {
        // _spikes.GetComponent<BoxCollider>().enabled = _estActif;

        
        Vector3 targetPos = _estActif ? new Vector3(transform.position.x, transform.position.y + 0.7f, transform.position.z) : new Vector3(transform.position.x, transform.position.y - 0.5f, transform.position.z);
        while (Vector3.Distance(_piques.transform.position, targetPos) > 0.1f)
        {
            _piques.transform.position = Vector3.MoveTowards(_piques.transform.position, targetPos, 5 * Time.deltaTime);
            yield return null;
        }
        if(_estActif)
        {
            SoundManager.Instance.JouerSon(_sonPiques, 0.05f, false);
            CheckForPlayer();
        }
        // _collider.enabled = _estActif;

        _piques.transform.position = targetPos;

    }

    void CheckForPlayer()
    {
        Collider[] colliders = Physics.OverlapBox(_piques.transform.position, new Vector3(0.5f, 0.5f, 0.5f), Quaternion.identity);

        foreach (Collider collider in colliders)
        {
            if (collider.CompareTag("Player"))
            {
                // Debug.Log("Player touched spikes");
                collider.GetComponent<Perso>().Mourir();
            }
        }
    }
    
    public void DisableCoroutines()
    {
        GameManager.moveEvent.RemoveListener(AlternanceEtat);
        StopAllCoroutines();
    }

    public void ActivateCoroutines()
    {
        GameManager.moveEvent.AddListener(AlternanceEtat);
        StartCoroutine(ActiverPiques());
    }
}
