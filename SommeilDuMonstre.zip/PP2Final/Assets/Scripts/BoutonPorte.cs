using System.Collections;
using UnityEngine;

public class BoutonPorte : MonoBehaviour
{
    [SerializeField] GameObject _door;
    [SerializeField] Renderer _renderer;
    [SerializeField] float _delaiActivation = 0.2f;
    [SerializeField] AudioClip _sonActivation;
    Material _material;
    bool _estActif = false;
    Coroutine _activeCoroutine; // Track the door coroutine

    void Start()
    {
        _material = _renderer.material;
        _material.color = Color.red;
        GameManager.moveEvent.AddListener(CheckForBlock);
    }

    void CheckForBlock()
    {
        _estActif = false;
        StartCoroutine(CoroutineCheckForBlock());
    }

    public IEnumerator CoroutineCheckForBlock()
    {
        yield return new WaitForSeconds(_delaiActivation);

        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.up, out hit, 3f))
        {
            if (hit.collider.CompareTag("Bloc") || hit.collider.CompareTag("Player"))
            {
                Activate();
            }
            else
            {
                Deactivate();
            }
        }
        else
        {
            Deactivate();
        }
    }

    public void Activate()
    {
        // Stop any existing door checks
        if (_activeCoroutine != null)
        {
            StopCoroutine(_activeCoroutine);
        }
        

        
        _door.SetActive(false);
        _estActif = true;
        if(_material.color != Color.green) SoundManager.Instance.JouerSon(_sonActivation, 0.6f);
        _material.color = Color.green;
        _material.SetColor("_EmissionColor", Color.green);
    }

    public void Deactivate()
    {
        _estActif = false;
        _material.color = Color.red;
        _material.SetColor("_EmissionColor", Color.red);


        // Start checking if something is keeping the door open
        if (_activeCoroutine != null)
        {
            StopCoroutine(_activeCoroutine);
        }
        _activeCoroutine = StartCoroutine(CoroutineDoorCheck());
    }

    IEnumerator CoroutineDoorCheck()
    {
        yield return new WaitForSeconds(0.05f);

        while (true)
        {
            // If button is reactivated, stop this check
            if (_estActif) yield break;

            bool keepOpen = false;
            RaycastHit[] hits = Physics.RaycastAll(_door.transform.position - new Vector3(0,2,0), Vector3.up , 3f);

            foreach (RaycastHit hit in hits)
            {
                if (hit.collider.CompareTag("Bloc") || hit.collider.CompareTag("Player"))
                {
                    keepOpen = true;
                    break;
                }
            }

            _door.SetActive(!keepOpen);
            
            yield return null;
        }
    }

    public void DisableCoroutines()
    {
        GameManager.moveEvent.RemoveListener(CheckForBlock);
        StopAllCoroutines();
    }   

    public void ActivateCoroutines()
    {
        GameManager.moveEvent.AddListener(CheckForBlock);
    }
}