using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


/// <summary>
/// ScriptableObject qui permet de gérer la navigation entre les scènes du jeu
/// </summary>
[CreateAssetMenu(fileName = "Navigation", menuName = "ScriptableObject/Navigation")]
public class SONavigation : ScriptableObject
{

    int _indexScenePrecedente;
    public int IndexScenePrecedente { get => _indexScenePrecedente; set => _indexScenePrecedente = value; }

    /// <summary>
    /// Méthode appelée pour démarrer le jeu.
    /// </summary>
    public void Jouer()
    {
        SceneManager.LoadScene("Niveau");
        
    }

    public void AllerNiveau(int index)
    {
        SceneManager.LoadScene("Niveau" + index);
    }
    /// <summary>
    /// Méthode appelée pour retourner au menu.
    /// </summary>
    public void AllerMenu()
    {
        SceneManager.LoadScene("Intro");
        // SoundManager.Instance.JouerMusiqueMenu();
    }

    /// <summary>
    /// Méthodes appelées pour charger la scène précédente dans l'ordre de la build.
    /// </summary>
    public void AllerScenePrecedente()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1); // Charge la scène précédente dans l'ordre de la build
    }

    public void Rejouer()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    /// <summary>
    /// Méthode appelée pour charger la scène générique.
    /// </summary>
    public void AllerSceneGenerique()
    {
        SceneManager.LoadScene("Generique");
    }



    /// <summary>
    /// Méthode appelée pour charger la scène suivante dans l'ordre de la build.
    /// </summary>
    public void AllerSceneSuivante()
    {
    
        int indexSceneCourante = SceneManager.GetActiveScene().buildIndex;
        int indexSceneSuivante = indexSceneCourante + 1;
        if (indexSceneSuivante < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(indexSceneSuivante);
        }
        else
        {
            SceneManager.LoadScene(0);
        }
    }
}
