using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RevePlate : MonoBehaviour
{
    Renderer _renderer;
    void Start()
    {
        // GameManager.moveEvent.AddListener(CheckForPlayer);
        // _renderer = GetComponent<Renderer>();
        // _renderer.material.color = Color.magenta;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            GameManager.Instance.ChangePostProcess();
        }
    }

    // void CheckForPlayer()
    // {
    //     StartCoroutine(CoroutineCheckForPlayer());
    // }
    
    // IEnumerator CoroutineCheckForPlayer()
    // {
    //     yield return new WaitForSeconds(0.2f);
    //     RaycastHit hit;
    //     if (Physics.Raycast(transform.position + Vector3.down, Vector3.up, out hit, 3f))
    //     {
    //         if (hit.collider.CompareTag("Player"))
    //         {
    //             // Debug.Log("Player on plate");
    //             GameManager.Instance.ChangePostProcess();
    //         }
    //     }
    // }
}
