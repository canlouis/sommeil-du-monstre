using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    [SerializeField] AudioSource _audioSourceEffets;
    AudioReverbFilter _reverbFilter;
    static SoundManager _instance;

    public static SoundManager Instance
    {
        get => _instance;
    }
    // Start is called before the first frame update
    void Start()
    {
        if (_instance == null)
        {
            _instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
        _reverbFilter = GetComponent<AudioReverbFilter>();
    }

    public void ActiverReverb(bool activer)
    {
        _reverbFilter.reverbPreset = activer ? AudioReverbPreset.Underwater : AudioReverbPreset.Off;
    }

    public void JouerSon(AudioClip son, float volume = 1, bool randomPitch = true)
    {
        if (randomPitch)
        {
            float pitch = Random.Range(0.9f, 1.1f);
            _audioSourceEffets.pitch = pitch;
        }
        else
        {
            _audioSourceEffets.pitch = 1;
        }
        _audioSourceEffets.PlayOneShot(son, volume);
    }

    public void ArreterSon()
    {
        _audioSourceEffets.Stop();
    }

    public IEnumerator JouerSonFadeOut(AudioClip son, float dureeGrognement = 5, float volume = 1)
    {
        JouerSon(son, volume);
        // Volume diminue progressivement
        float volumeActuel = 1;
        while (volumeActuel > 0)
        {
            volumeActuel -= Time.deltaTime / dureeGrognement;
            _audioSourceEffets.volume = volumeActuel;
            yield return null;
        }
    }

    void OnApplicationQuit()
    {
        PlayerPrefs.SetInt("NiveauAtteint", 0);
    }
}